﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using RoadTraffic.Domain;
using RoadTraffic.Services;
using System.Globalization;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace RoadTraffic.Controllers
{
    public class HomeController : Controller
    {
        private IConfiguration _configuration;
        private IRTCDataService _rtcDataService;
        private IRTCViewDataService _rtcViewDataService;
        private string _data;
        private List<RoadTrafficIncident> _incidents;
        private int _incidentCount;
        


        public HomeController(IConfiguration configuration, IRTCDataService rtcDataService, IRTCViewDataService rtcViewDataService)
        {
            _configuration = configuration;
            _rtcDataService = rtcDataService;
            _rtcViewDataService = rtcViewDataService;
            _data = _rtcDataService.GetData(_configuration["DataUrl"]);
            _incidents = _rtcDataService.GetDataList(_data);
            _incidentCount = _rtcDataService.TotalNumberOfIncidents(_incidents);
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Monthly()
        {
            List<MonthlyIncident> monthlyIncidents = _rtcViewDataService.GetMonthlyIncidentTable(_incidents);
            ViewData["Message"] = "A breakdown of road traffic incidents by month.";
            return View(monthlyIncidents);
        }

        public IActionResult MinMaxAvg()
        {
            List<IncidentStatistics> incidentStatistics = _rtcViewDataService.GetIncidentStatisticsTable(_incidents);
            ViewData["Message"] = "The minimum, maximum and average number of vehicles involved in incidents.";
            return View(incidentStatistics);
        }

        public IActionResult Time()
        {
            DateTime[] timeFrom = new DateTime[2];
            DateTime[] timeTo = new DateTime[2];

            timeFrom[0] = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 8, 0, 0); ;
            timeTo[0] = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0);
            timeFrom[1] = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 0, 0);
            timeTo[1] = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 18, 0, 0);

            List<PeakTimeStatistics> peaktimeStatistics = _rtcViewDataService.GetPeaktimeStatisticsTable(_incidents, timeFrom, timeTo);
            ViewData["Message"] = "The number of incidents at peak times.";
            return View(peaktimeStatistics);
        }

        public FileResult DownloadMonthly()
        {
            List<MonthlyIncident> monthlyIncidents = _rtcViewDataService.GetMonthlyIncidentTable(_incidents);

            var sb = new StringBuilder();
            foreach (var incidents in monthlyIncidents)
            {
                sb.AppendLine(incidents.Month + "," + incidents.Count + "," + incidents.Percent);
            }
            return File(new UTF8Encoding().GetBytes(sb.ToString()), "text/csv", "monthly.csv");
        }

        public FileResult DownloadStatistics()
        {
            List<IncidentStatistics> incidentStatistics = _rtcViewDataService.GetIncidentStatisticsTable(_incidents);

            var sb = new StringBuilder();
            foreach (var statistics in incidentStatistics)
            {
                sb.AppendLine(statistics.Metric + "," + statistics.Count);
            }
            return File(new UTF8Encoding().GetBytes(sb.ToString()), "text/csv", "statistics.csv");
        }

        public FileResult DownloadPeaktime()
        {
            DateTime[] timeFrom = new DateTime[2];
            DateTime[] timeTo = new DateTime[2];

            timeFrom[0] = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 8, 0, 0); ;
            timeTo[0] = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0);
            timeFrom[1] = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 0, 0);
            timeTo[1] = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 18, 0, 0);

            List<PeakTimeStatistics> peaktimeStatistics = _rtcViewDataService.GetPeaktimeStatisticsTable(_incidents, timeFrom, timeTo);

            var sb = new StringBuilder();
            foreach (var statistics in peaktimeStatistics)
            {
                sb.AppendLine(statistics.Timeframe + "," + statistics.Count + "," + statistics.Percent);
            }
            return File(new UTF8Encoding().GetBytes(sb.ToString()), "text/csv", "peaktime.csv");
        }


        public IActionResult Error()
        {
            return View();
        }
    }
}
