# RoadTraffic Application

RoadTraffic application is an ASP.NET Core Web Application running on the .NET Framework.


# Features
Features of the application are:
  - View a monthly breakdown of road traffic incidents
  - View minimum, maximum and average statistics 
  - View peak time statistics
  - Download each of the above as CSV file


# Development Environment
   - The application was developed using Visual Studio 2017 ASP.NET Core Web Application (.NET Framework)
   
  - To quickly and easily run this application, open the solution file in Visual Studio 2017 and run under IIS Express
  - Alternatively, you can deploy this application to a local instance of IIS
