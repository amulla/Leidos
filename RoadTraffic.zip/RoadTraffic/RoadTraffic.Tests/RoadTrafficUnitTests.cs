﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net;
using System.IO;
using RoadTraffic.Services;
using RoadTraffic.Domain;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Globalization;

namespace RoadTraffic.Tests
{
    [TestClass]
    public class RoadTrafficUnitTests
    {
        private string _url;
        private RTCDataService _rtcDataService;
        private RTCViewDataService _rtcViewDataService;
        private string _data;
        private List<RoadTrafficIncident> _roadTrafficIncidents;

        [TestInitialize]
        public void TestInit()
        {
            _url = @"https://files.datapress.com/leeds/dataset/road-traffic-accidents/2017-07-25T14:04:47.06/Copy%20of%20Leeds_RTC_2016.csv";
            _rtcDataService = new RTCDataService();
            _rtcViewDataService = new RTCViewDataService(_rtcDataService);

            _data = @"Reference Number,Grid Ref: Easting,Grid Ref: Northing,Number of Vehicles,Expr1,Accident Date,Time (24hr),1st Road Class,Road Surface,Lighting Conditions,Weather Conditions,Casualty Class,Casualty Severity,Sex of Casualty,Age of Casualty,Type of Vehicle
2181280,418241,442351,2,Leeds 2016,08/01/2016,1905,A,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Serious,Male,38,Motorcycle over 500cc
2191037,424993,432898,2,Leeds 2016,09/01/2016,1615,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,50,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,26,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,22,Car
3111091,439313,432376,2,Leeds 2016,01/01/2016,0956,A,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,57,Pedal cycle
3111178,426994,439957,2,Leeds 2016,01/01/2016,1115,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,59,Pedal cycle
3111395,427813,431257,1,Leeds 2016,01/01/2016,1352,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Female,53,Car
3111981,431496,432727,2,Leeds 2016,01/01/2016,2015,Unclassified,Wet / Damp,Darkness: street lights present and lit,Raining without high winds,Vehicle or pillion passenger,Slight,Female,22,Car
3120560,431880,430498,2,Leeds 2016,02/01/2016,1110,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,20,Car
3120872,429425,433999,1,Leeds 2016,02/01/2016,1638,A(M),Wet / Damp,Darkness: street lights present and lit,Raining without high winds,Driver or rider,Slight,Male,22,Car
3120872,429425,433999,1,Leeds 2016,02/01/2016,1638,A(M),Wet / Damp,Darkness: street lights present and lit,Raining without high winds,Vehicle or pillion passenger,Slight,Female,26,Car
3210161,440272,449564,2,Leeds 2016,01/02/2016,0500,Unclassified,Wet / Damp,Darkness: street lights present and lit,Fine with high winds,Driver or rider,Slight,Male,34,Car
3210475,431026,433540,1,Leeds 2016,01/02/2016,1039,Unclassified,Wet / Damp,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,28,Car
3210607,435675,434795,3,Leeds 2016,01/02/2016,1205,Unclassified,Dry,Daylight: street lights present,Fine with high winds,Driver or rider,Slight,Female,52,Car
3210607,435675,434795,3,Leeds 2016,01/02/2016,1205,Unclassified,Dry,Daylight: street lights present,Fine with high winds,Driver or rider,Slight,Female,66,Car
3210942,431881,435453,1,Leeds 2016,01/02/2016,1530,Unclassified,Dry,Daylight: street lights present,Fine with high winds,Pedestrian,Slight,Female,85,Car
3210980,432858,435382,2,Leeds 2016,01/02/2016,1545,Unclassified,Dry,Daylight: street lights present,Unknown,Vehicle or pillion passenger,Slight,Male,6,Car
3210980,432858,435382,2,Leeds 2016,01/02/2016,1545,Unclassified,Dry,Daylight: street lights present,Unknown,Vehicle or pillion passenger,Slight,Female,9,Car
3210980,432858,435382,2,Leeds 2016,01/02/2016,1545,Unclassified,Dry,Daylight: street lights present,Unknown,Vehicle or pillion passenger,Slight,Female,10,Car
3211478,426743,427878,1,Leeds 2016,01/02/2016,1510,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Female,26,Goods vehicle 3.5 tonnes mgw and under
3220231,432173,425966,2,Leeds 2016,02/02/2016,0810,Motorway,Dry,Daylight: street lights present,Fine with high winds,Driver or rider,Slight,Male,31,Car
3220493,430785,424533,2,Leeds 2016,02/02/2016,1126,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,73,Car
3221429,427896,436200,2,Leeds 2016,02/02/2016,1800,A,Wet / Damp,Darkness: street lights present and lit,Unknown,Driver or rider,Slight,Male,41,Pedal cycle
3310258,443655,437652,1,Leeds 2016,01/03/2016,0855,A(M),Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,54,Goods vehicle 7.5 tonnes mgw and over
3310294,427620,433951,2,Leeds 2016,01/03/2016,0910,Unclassified,Dry,Daylight: street lights present,Raining without high winds,Driver or rider,Slight,Male,21,Pedal cycle
3310740,424049,435487,2,Leeds 2016,01/03/2016,1352,Unclassified,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,40,Car
3311182,430959,435871,2,Leeds 2016,01/03/2016,1755,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Male,46,Pedal cycle
3311442,430221,432990,1,Leeds 2016,01/03/2016,1951,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Pedestrian,Serious,Female,75,Taxi/Private hire car
3320182,430335,439815,1,Leeds 2016,02/03/2016,0730,Unclassified,Frost / Ice,Daylight: street lights present,Unknown,Driver or rider,Slight,Male,33,Motorcycle over 50cc and up to 125cc
3320201,426441,428146,3,Leeds 2016,02/03/2016,0737,Unclassified,Dry,Daylight: street lights present,Unknown,Driver or rider,Slight,Male,27,Goods vehicle 3.5 tonnes mgw and under
3320255,431556,435177,1,Leeds 2016,02/03/2016,0853,A,Snow,Daylight: street lights present,Snowing without high winds,Pedestrian,Serious,Female,25,Car
3320317,441601,448977,3,Leeds 2016,02/03/2016,0932,Unclassified,Snow,Daylight: street lights present,Unknown,Driver or rider,Slight,Male,39,Car
3320317,441601,448977,3,Leeds 2016,02/03/2016,0932,Unclassified,Snow,Daylight: street lights present,Unknown,Driver or rider,Slight,Female,38,Car
3320317,441601,448977,3,Leeds 2016,02/03/2016,0932,Unclassified,Snow,Daylight: street lights present,Unknown,Driver or rider,Slight,Female,79,Car
3320331,431201,440854,1,Leeds 2016,02/03/2016,0935,A,Snow,Daylight: street lights present,Snowing without high winds,Driver or rider,Slight,Male,19,Motorcycle over 50cc and up to 125cc
3320404,429963,432509,2,Leeds 2016,02/03/2016,0930,Unclassified,Dry,Daylight: street lights present,Unknown,Vehicle or pillion passenger,Slight,Female,45,Bus or coach (17 or more passenger seats)
3410726,432779,429909,2,Leeds 2016,01/04/2016,1330,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,32,Motorcycle over 50cc and up to 125cc
3411318,431229,445744,1,Leeds 2016,01/04/2016,1852,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,31,Car
3420318,429898,435437,1,Leeds 2016,02/04/2016,0630,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Female,30,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,59,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,28,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,46,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,60,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,24,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,27,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,3,Car
3421179,427062,431803,2,Leeds 2016,02/04/2016,1810,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,34,Motorcycle over 500cc
3421556,430164,432839,2,Leeds 2016,02/04/2016,1420,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,23,Car
3421556,430164,432839,2,Leeds 2016,02/04/2016,1420,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,18,Car
3421556,430164,432839,2,Leeds 2016,02/04/2016,1420,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,45,Car
3531853,430606,434564,2,Leeds 2016,03/05/2016,2320,A,Wet / Damp,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,24,Car
3540209,435565,425884,3,Leeds 2016,04/05/2016,0738,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,22,Car
3540268,428067,426542,2,Leeds 2016,04/05/2016,0835,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,32,Car
3540271,435021,436216,2,Leeds 2016,04/05/2016,0842,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,14,Pedal cycle
3541105,428424,428709,3,Leeds 2016,04/05/2016,1638,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,37,Motorcycle over 500cc
3541510,436808,436502,1,Leeds 2016,04/05/2016,1810,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,6,Car
3550500,427325,431493,3,Leeds 2016,05/05/2016,1120,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,32,Car
3550500,427325,431493,3,Leeds 2016,05/05/2016,1120,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,53,Goods vehicle 3.5 tonnes mgw and under
3550500,427325,431493,3,Leeds 2016,05/05/2016,1120,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,29,Car
3551192,426727,431732,2,Leeds 2016,05/05/2016,1700,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,22,Car
3551673,430789,431378,1,Leeds 2016,05/05/2016,2201,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Serious,Male,24,Motorcycle over 50cc and up to 125cc
3560493,439389,432656,3,Leeds 2016,06/05/2016,1036,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,45,Goods vehicle 3.5 tonnes mgw and under
3560493,439389,432656,3,Leeds 2016,06/05/2016,1036,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,41,Car
3560710,436162,435075,1,Leeds 2016,06/05/2016,1240,A,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,70,Goods vehicle 3.5 tonnes mgw and under
3561186,425066,434279,2,Leeds 2016,06/05/2016,1630,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,21,M/cycle 50cc and under
3611239,443266,444199,2,Leeds 2016,01/06/2016,1822,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,38,Pedal cycle
3620591,431402,435029,2,Leeds 2016,02/06/2016,1214,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Female,53,Pedal cycle
3621398,418962,441738,2,Leeds 2016,02/06/2016,1730,B,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,21,Pedal cycle
3621562,426330,435490,2,Leeds 2016,02/06/2016,2030,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,56,Pedal cycle
3621592,425281,432980,2,Leeds 2016,02/06/2016,2045,B,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,49,Car
3621792,430529,433266,1,Leeds 2016,02/06/2016,2130,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Female,32,Car
3631313,431470,435116,1,Leeds 2016,03/06/2016,1847,A,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,75,Car
3631326,430072,433369,1,Leeds 2016,03/06/2016,1220,Unclassified,Dry,Daylight: street lights present,Unknown,Vehicle or pillion passenger,Slight,Male,4,Bus or coach (17 or more passenger seats)
3631374,429386,435421,2,Leeds 2016,03/06/2016,1930,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,21,Motorcycle over 50cc and up to 125cc
3631506,428311,435077,2,Leeds 2016,03/06/2016,2040,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,24,Pedal cycle
3631784,430062,433712,2,Leeds 2016,03/06/2016,0520,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Female,21,Pedal cycle
3640633,428381,434053,2,Leeds 2016,02/06/2016,1816,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,27,Car
3640633,428381,434053,2,Leeds 2016,02/06/2016,1816,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,5,Car
3640635,429412,433945,2,Leeds 2016,04/06/2016,1142,A(M),Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,32,Car
3640741,427793,434427,2,Leeds 2016,04/06/2016,1245,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,29,Car
3640741,427793,434427,2,Leeds 2016,04/06/2016,1245,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,36,Car
3720563,432455,438756,1,Leeds 2016,02/07/2016,1057,Unclassified,Wet / Damp,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Female,73,Car
3720858,431340,435054,2,Leeds 2016,02/07/2016,1408,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,54,Car
3721063,432158,427337,2,Leeds 2016,02/07/2016,1601,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,51,Car
3721063,432158,427337,2,Leeds 2016,02/07/2016,1601,Motorway,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,62,Car
3721135,430577,425368,1,Leeds 2016,02/07/2016,1652,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,51,Taxi/Private hire car
3721156,425970,436323,1,Leeds 2016,02/07/2016,1652,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Serious,Male,65,Car
3721205,430780,433454,1,Leeds 2016,02/07/2016,1526,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,70,Bus or coach (17 or more passenger seats)
3721205,430780,433454,1,Leeds 2016,02/07/2016,1526,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,50,Bus or coach (17 or more passenger seats)
3721205,430780,433454,1,Leeds 2016,02/07/2016,1526,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,47,Bus or coach (17 or more passenger seats)
3721205,430780,433454,1,Leeds 2016,02/07/2016,1526,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,51,Bus or coach (17 or more passenger seats)
3730711,427891,436195,2,Leeds 2016,03/07/2016,1153,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,29,Pedal cycle
3730942,425708,435406,2,Leeds 2016,03/07/2016,1430,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,32,Motorcycle over 50cc and up to 125cc
3731246,435544,438371,2,Leeds 2016,03/07/2016,1712,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,64,Car
3731246,435544,438371,2,Leeds 2016,03/07/2016,1712,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,76,Car
3731308,421928,441435,2,Leeds 2016,03/07/2016,1740,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,45,Car
3731431,429980,430876,2,Leeds 2016,03/07/2016,1800,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,37,Mobility Scooter
3740214,429334,435000,2,Leeds 2016,04/07/2016,0605,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,28,Pedal cycle
3811059,427116,433512,1,Leeds 2016,01/08/2016,1550,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,62,Bus or coach (17 or more passenger seats)
3811315,431381,435355,2,Leeds 2016,01/08/2016,1800,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,31,Car
3811595,431908,435069,2,Leeds 2016,01/08/2016,2019,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,37,Car
3811595,431908,435069,2,Leeds 2016,01/08/2016,2019,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,25,Taxi/Private hire car
3820302,428302,434114,2,Leeds 2016,02/08/2016,0815,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,31,Pedal cycle
3821313,430667,434302,2,Leeds 2016,02/08/2016,1830,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,55,Pedal cycle
3830263,428872,432496,2,Leeds 2016,03/08/2016,0655,Unclassified,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,47,Pedal cycle
3830291,431692,441552,1,Leeds 2016,03/08/2016,0745,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,27,Car
3830335,435875,426021,2,Leeds 2016,03/08/2016,0845,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,54,Car
3830729,427485,434593,2,Leeds 2016,03/08/2016,1330,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,29,Pedal cycle
3831111,427957,433622,2,Leeds 2016,03/08/2016,1559,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,53,Taxi/Private hire car
3831228,420750,445646,1,Leeds 2016,03/08/2016,1600,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,36,Pedal cycle
3840846,433898,434034,2,Leeds 2016,04/08/2016,1410,B,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,44,M/cycle 50cc and under
3840919,426991,427914,2,Leeds 2016,04/08/2016,1215,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,38,Bus or coach (17 or more passenger seats)
3840919,426991,427914,2,Leeds 2016,04/08/2016,1215,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,37,Bus or coach (17 or more passenger seats)
3841523,434120,433913,2,Leeds 2016,04/08/2016,1957,B,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,44,Car
3841523,434120,433913,2,Leeds 2016,04/08/2016,1957,B,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,18,Car
3850395,430539,436997,2,Leeds 2016,05/08/2016,0920,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,30,Car
3921449,429479,431201,2,Leeds 2016,02/09/2016,1807,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,15,M/cycle 50cc and under
3930215,431514,438536,2,Leeds 2016,03/09/2016,0235,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,22,Car
3930839,422424,432775,3,Leeds 2016,03/09/2016,1305,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Driver or rider,Serious,Male,64,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Driver or rider,Slight,Male,53,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Female,38,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Female,12,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Driver or rider,Slight,Male,25,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Male,4,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Male,41,Car
3931321,427519,435875,2,Leeds 2016,03/09/2016,1530,B,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,27,Car
3931892,428750,434077,2,Leeds 2016,03/09/2016,2350,Unclassified,Wet / Damp,Darkness: street lights present and lit,Fine without high winds,Vehicle or pillion passenger,Slight,Female,22,Taxi/Private hire car
3940394,428526,432685,2,Leeds 2016,04/09/2016,0800,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,34,Car
3940520,423345,444486,2,Leeds 2016,04/09/2016,1025,A,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,21,Car
3940520,423345,444486,2,Leeds 2016,04/09/2016,1025,A,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,66,Car
3940520,423345,444486,2,Leeds 2016,04/09/2016,1025,A,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Serious,Female,60,Car
3941118,437762,432564,2,Leeds 2016,04/09/2016,1630,Motorway,Wet / Damp,Daylight: street lights present,Raining without high winds,Driver or rider,Slight,Female,28,Car
3941118,437762,432564,2,Leeds 2016,04/09/2016,1630,Motorway,Wet / Damp,Daylight: street lights present,Raining without high winds,Driver or rider,Slight,Male,42,Car
3941118,437762,432564,2,Leeds 2016,04/09/2016,1630,Motorway,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Female,42,Car
3941118,437762,432564,2,Leeds 2016,04/09/2016,1630,Motorway,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Male,21,Car
3A31406,436137,427930,2,Leeds 2016,03/10/2016,0500,A,Dry,Darkness: street lighting unknown,Unknown,Driver or rider,Slight,Male,28,Car
3A31453,424506,434441,2,Leeds 2016,03/10/2016,1745,B,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,38,Pedal cycle
3A31485,427600,436795,2,Leeds 2016,03/10/2016,1911,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,36,Pedal cycle
3A40219,439316,432380,2,Leeds 2016,04/10/2016,0748,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,23,Car
3A40325,437575,433215,2,Leeds 2016,03/10/2016,1630,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,30,Car
3A40735,432794,434287,1,Leeds 2016,04/10/2016,1307,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,20,Motorcycle over 50cc and up to 125cc
3A41340,432221,433184,1,Leeds 2016,04/10/2016,1800,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,17,Motorcycle over 125cc and up to 500cc
3A50232,435674,434794,2,Leeds 2016,05/10/2016,0850,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,46,Car
3A50248,427963,433621,2,Leeds 2016,05/10/2016,0837,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,42,Pedal cycle
3A50290,436330,434209,2,Leeds 2016,05/10/2016,0900,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,21,Motorcycle over 50cc and up to 125cc
3B20858,424151,428163,2,Leeds 2016,02/11/2016,1418,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,22,Car
3B20858,424151,428163,2,Leeds 2016,02/11/2016,1418,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,26,Car
3B21094,431913,435719,2,Leeds 2016,02/11/2016,1600,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,38,Goods vehicle 3.5 tonnes mgw and under
3B21115,428718,426013,2,Leeds 2016,02/11/2016,1614,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,23,Car
3B21115,428718,426013,2,Leeds 2016,02/11/2016,1614,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,50,Car
3B21169,429030,431750,5,Leeds 2016,02/11/2016,1645,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,31,Car
3B21169,429030,431750,5,Leeds 2016,02/11/2016,1645,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Female,36,Car
3B21169,429030,431750,5,Leeds 2016,02/11/2016,1645,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,30,Car
3B21169,429030,431750,5,Leeds 2016,02/11/2016,1645,Motorway,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Serious,Male,31,Car
3B21169,429030,431750,5,Leeds 2016,02/11/2016,1645,Motorway,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,10,Car
3B21483,429788,430628,2,Leeds 2016,02/11/2016,1900,A,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Male,39,Pedal cycle
3C40865,432213,434656,2,Leeds 2016,04/12/2016,1335,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,47,Car
3C40865,432213,434656,2,Leeds 2016,04/12/2016,1335,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,39,Car
3C40941,431470,433501,1,Leeds 2016,04/12/2016,1422,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Female,8,Car
3C41053,435737,436946,2,Leeds 2016,04/12/2016,1526,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,25,Car
3C41053,435737,436946,2,Leeds 2016,04/12/2016,1526,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,69,Car
3C41053,435737,436946,2,Leeds 2016,04/12/2016,1526,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,48,Car
3C41203,430759,439910,2,Leeds 2016,04/12/2016,1645,Unclassified,Wet / Damp,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,25,Car
3C41203,430759,439910,2,Leeds 2016,04/12/2016,1645,Unclassified,Wet / Damp,Darkness: street lights present and lit,Fine without high winds,Vehicle or pillion passenger,Slight,Male,25,Car
3C41203,430759,439910,2,Leeds 2016,04/12/2016,1645,Unclassified,Wet / Damp,Darkness: street lights present and lit,Fine without high winds,Vehicle or pillion passenger,Serious,Male,1,Car
3C41220,432240,426274,2,Leeds 2016,04/12/2016,1610,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,30,Car
3C41220,432240,426274,2,Leeds 2016,04/12/2016,1610,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,57,Car
3C41498,436776,443749,1,Leeds 2016,04/12/2016,1925,A,Dry,Darkness: no street lighting,Fine without high winds,Vehicle or pillion passenger,Slight,Male,18,Car
";
        }

        [TestMethod]
        public void GetDataTest()
        {
            // Arrange
            //Done in init

            // Act
            string rtcData = _rtcDataService.GetData(_url);

            // Assert
            Assert.IsTrue(rtcData.Length > 0);
        }

        [TestMethod]
        public void PutDataInListTest()
        {
            // Arrange
            // Done in init

            // Act
            _roadTrafficIncidents = _rtcDataService.GetDataList(_data);

            // Assert
            Assert.AreEqual(168, _roadTrafficIncidents.Count);
        }

        [TestMethod]
        public void IncidentCountTest()
        {
            // Arrange
            string data = @"Reference Number,Grid Ref: Easting,Grid Ref: Northing,Number of Vehicles,Expr1,Accident Date,Time (24hr),1st Road Class,Road Surface,Lighting Conditions,Weather Conditions,Casualty Class,Casualty Severity,Sex of Casualty,Age of Casualty,Type of Vehicle
2181280,418241,442351,2,Leeds 2016,08/01/2016,1905,A,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Serious,Male,38,Motorcycle over 500cc
2191037,424993,432898,2,Leeds 2016,09/01/2016,1615,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,50,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,26,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,22,Car
3111091,439313,432376,2,Leeds 2016,01/01/2016,0956,A,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,57,Pedal cycle
";
            List<RoadTrafficIncident> roadTrafficIncidents = _rtcDataService.GetDataList(data);

            // Act
            int count = _rtcDataService.TotalNumberOfIncidents(roadTrafficIncidents);

            // Assert
            Assert.AreEqual(5, count);
        }

        [TestMethod]
        public void MonthlyStatisticsTest()
        {
            // Arrange
            string data = @"Reference Number,Grid Ref: Easting,Grid Ref: Northing,Number of Vehicles,Expr1,Accident Date,Time (24hr),1st Road Class,Road Surface,Lighting Conditions,Weather Conditions,Casualty Class,Casualty Severity,Sex of Casualty,Age of Casualty,Type of Vehicle
2181280,418241,442351,2,Leeds 2016,08/01/2016,1905,A,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Serious,Male,38,Motorcycle over 500cc
2191037,424993,432898,2,Leeds 2016,09/01/2016,1615,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,50,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,26,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,22,Car
3111091,439313,432376,2,Leeds 2016,01/01/2016,0956,A,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,57,Pedal cycle
3111178,426994,439957,2,Leeds 2016,01/01/2016,1115,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,59,Pedal cycle
3111395,427813,431257,1,Leeds 2016,01/01/2016,1352,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Female,53,Car
3111981,431496,432727,2,Leeds 2016,01/01/2016,2015,Unclassified,Wet / Damp,Darkness: street lights present and lit,Raining without high winds,Vehicle or pillion passenger,Slight,Female,22,Car
3120560,431880,430498,2,Leeds 2016,02/01/2016,1110,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,20,Car
3120872,429425,433999,1,Leeds 2016,02/01/2016,1638,A(M),Wet / Damp,Darkness: street lights present and lit,Raining without high winds,Driver or rider,Slight,Male,22,Car
3120872,429425,433999,1,Leeds 2016,02/01/2016,1638,A(M),Wet / Damp,Darkness: street lights present and lit,Raining without high winds,Vehicle or pillion passenger,Slight,Female,26,Car
3210161,440272,449564,2,Leeds 2016,01/02/2016,0500,Unclassified,Wet / Damp,Darkness: street lights present and lit,Fine with high winds,Driver or rider,Slight,Male,34,Car
3210475,431026,433540,1,Leeds 2016,01/02/2016,1039,Unclassified,Wet / Damp,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,28,Car
3210607,435675,434795,3,Leeds 2016,01/02/2016,1205,Unclassified,Dry,Daylight: street lights present,Fine with high winds,Driver or rider,Slight,Female,52,Car
3210607,435675,434795,3,Leeds 2016,01/02/2016,1205,Unclassified,Dry,Daylight: street lights present,Fine with high winds,Driver or rider,Slight,Female,66,Car
3210942,431881,435453,1,Leeds 2016,01/02/2016,1530,Unclassified,Dry,Daylight: street lights present,Fine with high winds,Pedestrian,Slight,Female,85,Car
3210980,432858,435382,2,Leeds 2016,01/02/2016,1545,Unclassified,Dry,Daylight: street lights present,Unknown,Vehicle or pillion passenger,Slight,Male,6,Car
3210980,432858,435382,2,Leeds 2016,01/02/2016,1545,Unclassified,Dry,Daylight: street lights present,Unknown,Vehicle or pillion passenger,Slight,Female,9,Car
3210980,432858,435382,2,Leeds 2016,01/02/2016,1545,Unclassified,Dry,Daylight: street lights present,Unknown,Vehicle or pillion passenger,Slight,Female,10,Car
3211478,426743,427878,1,Leeds 2016,01/02/2016,1510,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Female,26,Goods vehicle 3.5 tonnes mgw and under
3220231,432173,425966,2,Leeds 2016,02/02/2016,0810,Motorway,Dry,Daylight: street lights present,Fine with high winds,Driver or rider,Slight,Male,31,Car
3220493,430785,424533,2,Leeds 2016,02/02/2016,1126,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,73,Car
3221429,427896,436200,2,Leeds 2016,02/02/2016,1800,A,Wet / Damp,Darkness: street lights present and lit,Unknown,Driver or rider,Slight,Male,41,Pedal cycle
3310258,443655,437652,1,Leeds 2016,01/03/2016,0855,A(M),Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,54,Goods vehicle 7.5 tonnes mgw and over
3310294,427620,433951,2,Leeds 2016,01/03/2016,0910,Unclassified,Dry,Daylight: street lights present,Raining without high winds,Driver or rider,Slight,Male,21,Pedal cycle
3310740,424049,435487,2,Leeds 2016,01/03/2016,1352,Unclassified,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,40,Car
3311182,430959,435871,2,Leeds 2016,01/03/2016,1755,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Male,46,Pedal cycle
3311442,430221,432990,1,Leeds 2016,01/03/2016,1951,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Pedestrian,Serious,Female,75,Taxi/Private hire car
3320182,430335,439815,1,Leeds 2016,02/03/2016,0730,Unclassified,Frost / Ice,Daylight: street lights present,Unknown,Driver or rider,Slight,Male,33,Motorcycle over 50cc and up to 125cc
3320201,426441,428146,3,Leeds 2016,02/03/2016,0737,Unclassified,Dry,Daylight: street lights present,Unknown,Driver or rider,Slight,Male,27,Goods vehicle 3.5 tonnes mgw and under
3320255,431556,435177,1,Leeds 2016,02/03/2016,0853,A,Snow,Daylight: street lights present,Snowing without high winds,Pedestrian,Serious,Female,25,Car
3320317,441601,448977,3,Leeds 2016,02/03/2016,0932,Unclassified,Snow,Daylight: street lights present,Unknown,Driver or rider,Slight,Male,39,Car
3320317,441601,448977,3,Leeds 2016,02/03/2016,0932,Unclassified,Snow,Daylight: street lights present,Unknown,Driver or rider,Slight,Female,38,Car
3320317,441601,448977,3,Leeds 2016,02/03/2016,0932,Unclassified,Snow,Daylight: street lights present,Unknown,Driver or rider,Slight,Female,79,Car
3320331,431201,440854,1,Leeds 2016,02/03/2016,0935,A,Snow,Daylight: street lights present,Snowing without high winds,Driver or rider,Slight,Male,19,Motorcycle over 50cc and up to 125cc
3320404,429963,432509,2,Leeds 2016,02/03/2016,0930,Unclassified,Dry,Daylight: street lights present,Unknown,Vehicle or pillion passenger,Slight,Female,45,Bus or coach (17 or more passenger seats)
3410726,432779,429909,2,Leeds 2016,01/04/2016,1330,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,32,Motorcycle over 50cc and up to 125cc
3411318,431229,445744,1,Leeds 2016,01/04/2016,1852,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,31,Car
3420318,429898,435437,1,Leeds 2016,02/04/2016,0630,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Female,30,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,59,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,28,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,46,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,60,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,24,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,27,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,3,Car
3421179,427062,431803,2,Leeds 2016,02/04/2016,1810,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,34,Motorcycle over 500cc
3421556,430164,432839,2,Leeds 2016,02/04/2016,1420,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,23,Car
3421556,430164,432839,2,Leeds 2016,02/04/2016,1420,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,18,Car
3421556,430164,432839,2,Leeds 2016,02/04/2016,1420,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,45,Car
3531853,430606,434564,2,Leeds 2016,03/05/2016,2320,A,Wet / Damp,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,24,Car
3540209,435565,425884,3,Leeds 2016,04/05/2016,0738,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,22,Car
3540268,428067,426542,2,Leeds 2016,04/05/2016,0835,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,32,Car
3540271,435021,436216,2,Leeds 2016,04/05/2016,0842,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,14,Pedal cycle
3541105,428424,428709,3,Leeds 2016,04/05/2016,1638,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,37,Motorcycle over 500cc
3541510,436808,436502,1,Leeds 2016,04/05/2016,1810,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,6,Car
3550500,427325,431493,3,Leeds 2016,05/05/2016,1120,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,32,Car
3550500,427325,431493,3,Leeds 2016,05/05/2016,1120,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,53,Goods vehicle 3.5 tonnes mgw and under
3550500,427325,431493,3,Leeds 2016,05/05/2016,1120,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,29,Car
3551192,426727,431732,2,Leeds 2016,05/05/2016,1700,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,22,Car
3551673,430789,431378,1,Leeds 2016,05/05/2016,2201,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Serious,Male,24,Motorcycle over 50cc and up to 125cc
3560493,439389,432656,3,Leeds 2016,06/05/2016,1036,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,45,Goods vehicle 3.5 tonnes mgw and under
3560493,439389,432656,3,Leeds 2016,06/05/2016,1036,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,41,Car
3560710,436162,435075,1,Leeds 2016,06/05/2016,1240,A,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,70,Goods vehicle 3.5 tonnes mgw and under
3561186,425066,434279,2,Leeds 2016,06/05/2016,1630,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,21,M/cycle 50cc and under
3611239,443266,444199,2,Leeds 2016,01/06/2016,1822,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,38,Pedal cycle
3620591,431402,435029,2,Leeds 2016,02/06/2016,1214,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Female,53,Pedal cycle
3621398,418962,441738,2,Leeds 2016,02/06/2016,1730,B,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,21,Pedal cycle
3621562,426330,435490,2,Leeds 2016,02/06/2016,2030,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,56,Pedal cycle
3621592,425281,432980,2,Leeds 2016,02/06/2016,2045,B,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,49,Car
3621792,430529,433266,1,Leeds 2016,02/06/2016,2130,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Female,32,Car
3631313,431470,435116,1,Leeds 2016,03/06/2016,1847,A,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,75,Car
3631326,430072,433369,1,Leeds 2016,03/06/2016,1220,Unclassified,Dry,Daylight: street lights present,Unknown,Vehicle or pillion passenger,Slight,Male,4,Bus or coach (17 or more passenger seats)
3631374,429386,435421,2,Leeds 2016,03/06/2016,1930,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,21,Motorcycle over 50cc and up to 125cc
3631506,428311,435077,2,Leeds 2016,03/06/2016,2040,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,24,Pedal cycle
3631784,430062,433712,2,Leeds 2016,03/06/2016,0520,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Female,21,Pedal cycle
3640633,428381,434053,2,Leeds 2016,02/06/2016,1816,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,27,Car
3640633,428381,434053,2,Leeds 2016,02/06/2016,1816,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,5,Car
3640635,429412,433945,2,Leeds 2016,04/06/2016,1142,A(M),Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,32,Car
3640741,427793,434427,2,Leeds 2016,04/06/2016,1245,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,29,Car
3640741,427793,434427,2,Leeds 2016,04/06/2016,1245,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,36,Car
3720563,432455,438756,1,Leeds 2016,02/07/2016,1057,Unclassified,Wet / Damp,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Female,73,Car
3720858,431340,435054,2,Leeds 2016,02/07/2016,1408,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,54,Car
3721063,432158,427337,2,Leeds 2016,02/07/2016,1601,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,51,Car
3721063,432158,427337,2,Leeds 2016,02/07/2016,1601,Motorway,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,62,Car
3721135,430577,425368,1,Leeds 2016,02/07/2016,1652,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,51,Taxi/Private hire car
3721156,425970,436323,1,Leeds 2016,02/07/2016,1652,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Serious,Male,65,Car
3721205,430780,433454,1,Leeds 2016,02/07/2016,1526,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,70,Bus or coach (17 or more passenger seats)
3721205,430780,433454,1,Leeds 2016,02/07/2016,1526,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,50,Bus or coach (17 or more passenger seats)
3721205,430780,433454,1,Leeds 2016,02/07/2016,1526,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,47,Bus or coach (17 or more passenger seats)
3721205,430780,433454,1,Leeds 2016,02/07/2016,1526,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,51,Bus or coach (17 or more passenger seats)
3730711,427891,436195,2,Leeds 2016,03/07/2016,1153,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,29,Pedal cycle
3730942,425708,435406,2,Leeds 2016,03/07/2016,1430,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,32,Motorcycle over 50cc and up to 125cc
3731246,435544,438371,2,Leeds 2016,03/07/2016,1712,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,64,Car
3731246,435544,438371,2,Leeds 2016,03/07/2016,1712,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,76,Car
3731308,421928,441435,2,Leeds 2016,03/07/2016,1740,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,45,Car
3731431,429980,430876,2,Leeds 2016,03/07/2016,1800,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,37,Mobility Scooter
3740214,429334,435000,2,Leeds 2016,04/07/2016,0605,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,28,Pedal cycle
3811059,427116,433512,1,Leeds 2016,01/08/2016,1550,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,62,Bus or coach (17 or more passenger seats)
3811315,431381,435355,2,Leeds 2016,01/08/2016,1800,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,31,Car
3811595,431908,435069,2,Leeds 2016,01/08/2016,2019,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,37,Car
3811595,431908,435069,2,Leeds 2016,01/08/2016,2019,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,25,Taxi/Private hire car
3820302,428302,434114,2,Leeds 2016,02/08/2016,0815,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,31,Pedal cycle
3821313,430667,434302,2,Leeds 2016,02/08/2016,1830,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,55,Pedal cycle
3830263,428872,432496,2,Leeds 2016,03/08/2016,0655,Unclassified,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,47,Pedal cycle
3830291,431692,441552,1,Leeds 2016,03/08/2016,0745,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,27,Car
3830335,435875,426021,2,Leeds 2016,03/08/2016,0845,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,54,Car
3830729,427485,434593,2,Leeds 2016,03/08/2016,1330,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,29,Pedal cycle
3831111,427957,433622,2,Leeds 2016,03/08/2016,1559,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,53,Taxi/Private hire car
3831228,420750,445646,1,Leeds 2016,03/08/2016,1600,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,36,Pedal cycle
3840846,433898,434034,2,Leeds 2016,04/08/2016,1410,B,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,44,M/cycle 50cc and under
3840919,426991,427914,2,Leeds 2016,04/08/2016,1215,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,38,Bus or coach (17 or more passenger seats)
3840919,426991,427914,2,Leeds 2016,04/08/2016,1215,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,37,Bus or coach (17 or more passenger seats)
3841523,434120,433913,2,Leeds 2016,04/08/2016,1957,B,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,44,Car
3841523,434120,433913,2,Leeds 2016,04/08/2016,1957,B,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,18,Car
3850395,430539,436997,2,Leeds 2016,05/08/2016,0920,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,30,Car
3921449,429479,431201,2,Leeds 2016,02/09/2016,1807,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,15,M/cycle 50cc and under
3930215,431514,438536,2,Leeds 2016,03/09/2016,0235,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,22,Car
3930839,422424,432775,3,Leeds 2016,03/09/2016,1305,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Driver or rider,Serious,Male,64,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Driver or rider,Slight,Male,53,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Female,38,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Female,12,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Driver or rider,Slight,Male,25,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Male,4,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Male,41,Car
3931321,427519,435875,2,Leeds 2016,03/09/2016,1530,B,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,27,Car
3931892,428750,434077,2,Leeds 2016,03/09/2016,2350,Unclassified,Wet / Damp,Darkness: street lights present and lit,Fine without high winds,Vehicle or pillion passenger,Slight,Female,22,Taxi/Private hire car
3940394,428526,432685,2,Leeds 2016,04/09/2016,0800,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,34,Car
3940520,423345,444486,2,Leeds 2016,04/09/2016,1025,A,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,21,Car
3940520,423345,444486,2,Leeds 2016,04/09/2016,1025,A,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,66,Car
3940520,423345,444486,2,Leeds 2016,04/09/2016,1025,A,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Serious,Female,60,Car
3941118,437762,432564,2,Leeds 2016,04/09/2016,1630,Motorway,Wet / Damp,Daylight: street lights present,Raining without high winds,Driver or rider,Slight,Female,28,Car
3941118,437762,432564,2,Leeds 2016,04/09/2016,1630,Motorway,Wet / Damp,Daylight: street lights present,Raining without high winds,Driver or rider,Slight,Male,42,Car
3941118,437762,432564,2,Leeds 2016,04/09/2016,1630,Motorway,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Female,42,Car
3941118,437762,432564,2,Leeds 2016,04/09/2016,1630,Motorway,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Male,21,Car
3A31406,436137,427930,2,Leeds 2016,03/10/2016,0500,A,Dry,Darkness: street lighting unknown,Unknown,Driver or rider,Slight,Male,28,Car
3A31453,424506,434441,2,Leeds 2016,03/10/2016,1745,B,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,38,Pedal cycle
3A31485,427600,436795,2,Leeds 2016,03/10/2016,1911,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,36,Pedal cycle
3A40219,439316,432380,2,Leeds 2016,04/10/2016,0748,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,23,Car
3A40325,437575,433215,2,Leeds 2016,03/10/2016,1630,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,30,Car
3A40735,432794,434287,1,Leeds 2016,04/10/2016,1307,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,20,Motorcycle over 50cc and up to 125cc
3A41340,432221,433184,1,Leeds 2016,04/10/2016,1800,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,17,Motorcycle over 125cc and up to 500cc
3A50232,435674,434794,2,Leeds 2016,05/10/2016,0850,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,46,Car
3A50248,427963,433621,2,Leeds 2016,05/10/2016,0837,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,42,Pedal cycle
3A50290,436330,434209,2,Leeds 2016,05/10/2016,0900,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,21,Motorcycle over 50cc and up to 125cc
3B20858,424151,428163,2,Leeds 2016,02/11/2016,1418,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,22,Car
3B20858,424151,428163,2,Leeds 2016,02/11/2016,1418,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,26,Car
3B21094,431913,435719,2,Leeds 2016,02/11/2016,1600,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,38,Goods vehicle 3.5 tonnes mgw and under
3B21115,428718,426013,2,Leeds 2016,02/11/2016,1614,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,23,Car
3B21115,428718,426013,2,Leeds 2016,02/11/2016,1614,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,50,Car
3B21169,429030,431750,5,Leeds 2016,02/11/2016,1645,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,31,Car
3B21169,429030,431750,5,Leeds 2016,02/11/2016,1645,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Female,36,Car
3B21169,429030,431750,5,Leeds 2016,02/11/2016,1645,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,30,Car
3B21169,429030,431750,5,Leeds 2016,02/11/2016,1645,Motorway,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Serious,Male,31,Car
3B21169,429030,431750,5,Leeds 2016,02/11/2016,1645,Motorway,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,10,Car
3B21483,429788,430628,2,Leeds 2016,02/11/2016,1900,A,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Male,39,Pedal cycle
3C40865,432213,434656,2,Leeds 2016,04/12/2016,1335,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,47,Car
3C40865,432213,434656,2,Leeds 2016,04/12/2016,1335,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,39,Car
3C40941,431470,433501,1,Leeds 2016,04/12/2016,1422,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Female,8,Car
3C41053,435737,436946,2,Leeds 2016,04/12/2016,1526,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,25,Car
3C41053,435737,436946,2,Leeds 2016,04/12/2016,1526,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,69,Car
3C41053,435737,436946,2,Leeds 2016,04/12/2016,1526,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,48,Car
3C41203,430759,439910,2,Leeds 2016,04/12/2016,1645,Unclassified,Wet / Damp,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,25,Car
3C41203,430759,439910,2,Leeds 2016,04/12/2016,1645,Unclassified,Wet / Damp,Darkness: street lights present and lit,Fine without high winds,Vehicle or pillion passenger,Slight,Male,25,Car
3C41203,430759,439910,2,Leeds 2016,04/12/2016,1645,Unclassified,Wet / Damp,Darkness: street lights present and lit,Fine without high winds,Vehicle or pillion passenger,Serious,Male,1,Car
3C41220,432240,426274,2,Leeds 2016,04/12/2016,1610,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,30,Car
3C41220,432240,426274,2,Leeds 2016,04/12/2016,1610,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,57,Car
3C41498,436776,443749,1,Leeds 2016,04/12/2016,1925,A,Dry,Darkness: no street lighting,Fine without high winds,Vehicle or pillion passenger,Slight,Male,18,Car
";

            List<RoadTrafficIncident> roadTrafficIncidents = _rtcDataService.GetDataList(data);

            // Act
            int countJan = _rtcDataService.TotalNumberOfIncidentsByMonth(roadTrafficIncidents, 1);
            int countFeb = _rtcDataService.TotalNumberOfIncidentsByMonth(roadTrafficIncidents, 2);
            int countMar = _rtcDataService.TotalNumberOfIncidentsByMonth(roadTrafficIncidents, 3);
            int countApr = _rtcDataService.TotalNumberOfIncidentsByMonth(roadTrafficIncidents, 4);
            int countMay = _rtcDataService.TotalNumberOfIncidentsByMonth(roadTrafficIncidents, 5);
            int countJun = _rtcDataService.TotalNumberOfIncidentsByMonth(roadTrafficIncidents, 6);
            int countJul = _rtcDataService.TotalNumberOfIncidentsByMonth(roadTrafficIncidents, 7);
            int countAug = _rtcDataService.TotalNumberOfIncidentsByMonth(roadTrafficIncidents, 8);
            int countSep = _rtcDataService.TotalNumberOfIncidentsByMonth(roadTrafficIncidents, 9);
            int countOct = _rtcDataService.TotalNumberOfIncidentsByMonth(roadTrafficIncidents, 10);
            int countNov = _rtcDataService.TotalNumberOfIncidentsByMonth(roadTrafficIncidents, 11);
            int countDec = _rtcDataService.TotalNumberOfIncidentsByMonth(roadTrafficIncidents, 12);

            // Assert
            Assert.AreEqual(11, countJan);
            Assert.AreEqual(12, countFeb);
            Assert.AreEqual(13, countMar);
            Assert.AreEqual(14, countApr);
            Assert.AreEqual(15, countMay);
            Assert.AreEqual(16, countJun);
            Assert.AreEqual(17, countJul);
            Assert.AreEqual(18, countAug);
            Assert.AreEqual(19, countSep);
            Assert.AreEqual(10, countOct);
            Assert.AreEqual(11, countNov);
            Assert.AreEqual(12, countDec);
        }

        [TestMethod]
        public void MinimumVehicleTest()
        {
            // Arrange
            string data = @"Reference Number,Grid Ref: Easting,Grid Ref: Northing,Number of Vehicles,Expr1,Accident Date,Time (24hr),1st Road Class,Road Surface,Lighting Conditions,Weather Conditions,Casualty Class,Casualty Severity,Sex of Casualty,Age of Casualty,Type of Vehicle
2181280,418241,442351,2,Leeds 2016,08/01/2016,1905,A,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Serious,Male,38,Motorcycle over 500cc
2191037,424993,432898,2,Leeds 2016,09/01/2016,1615,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,50,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,26,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,22,Car
3111091,439313,432376,2,Leeds 2016,01/01/2016,0956,A,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,57,Pedal cycle
3111178,426994,439957,2,Leeds 2016,01/01/2016,1115,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,59,Pedal cycle
3111395,427813,431257,1,Leeds 2016,01/01/2016,1352,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Female,53,Car
3111981,431496,432727,2,Leeds 2016,01/01/2016,2015,Unclassified,Wet / Damp,Darkness: street lights present and lit,Raining without high winds,Vehicle or pillion passenger,Slight,Female,22,Car
3120560,431880,430498,2,Leeds 2016,02/01/2016,1110,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,20,Car
3120872,429425,433999,1,Leeds 2016,02/01/2016,1638,A(M),Wet / Damp,Darkness: street lights present and lit,Raining without high winds,Driver or rider,Slight,Male,22,Car
3C41498,436776,443749,1,Leeds 2016,04/12/2016,1925,A,Dry,Darkness: no street lighting,Fine without high winds,Vehicle or pillion passenger,Slight,Male,18,Car
";
            List<RoadTrafficIncident> roadTrafficIncidents = _rtcDataService.GetDataList(data);

            // Act
            int minVehicles = _rtcDataService.MinimumVehicles(roadTrafficIncidents);

            // Assert
            Assert.AreEqual(1, minVehicles);
        }

        [TestMethod]
        public void MaximumVehicleTest()
        {
            // Arrange
            string data = @"Reference Number,Grid Ref: Easting,Grid Ref: Northing,Number of Vehicles,Expr1,Accident Date,Time (24hr),1st Road Class,Road Surface,Lighting Conditions,Weather Conditions,Casualty Class,Casualty Severity,Sex of Casualty,Age of Casualty,Type of Vehicle
2181280,418241,442351,2,Leeds 2016,08/01/2016,1905,A,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Serious,Male,38,Motorcycle over 500cc
2191037,424993,432898,2,Leeds 2016,09/01/2016,1615,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,50,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,26,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,22,Car
3C41220,432240,426274,2,Leeds 2016,04/12/2016,1610,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,57,Car
3C41498,436776,443749,9,Leeds 2016,04/12/2016,1925,A,Dry,Darkness: no street lighting,Fine without high winds,Vehicle or pillion passenger,Slight,Male,18,Car
";

            List<RoadTrafficIncident> roadTrafficIncidents = _rtcDataService.GetDataList(data);

            // Act
            int maxVehicles = _rtcDataService.MaximumVehicles(roadTrafficIncidents);

            // Assert
            Assert.AreEqual(9, maxVehicles);
        }

        [TestMethod]
        public void AverageVehicleTest()
        {
            // Arrange
            string data = @"Reference Number,Grid Ref: Easting,Grid Ref: Northing,Number of Vehicles,Expr1,Accident Date,Time (24hr),1st Road Class,Road Surface,Lighting Conditions,Weather Conditions,Casualty Class,Casualty Severity,Sex of Casualty,Age of Casualty,Type of Vehicle
2181280,418241,442351,2,Leeds 2016,08/01/2016,1905,A,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Serious,Male,38,Motorcycle over 500cc
2191037,424993,432898,2,Leeds 2016,09/01/2016,1615,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,50,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,26,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,22,Car
3C41220,432240,426274,2,Leeds 2016,04/12/2016,1610,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,57,Car
3C41498,436776,443749,9,Leeds 2016,04/12/2016,1925,A,Dry,Darkness: no street lighting,Fine without high winds,Vehicle or pillion passenger,Slight,Male,18,Car
";

            List<RoadTrafficIncident> roadTrafficIncidents = _rtcDataService.GetDataList(data);

            // Act
            double aveVehicles = _rtcDataService.AverageVehicles(roadTrafficIncidents);

            // Assert
            Assert.AreEqual(3.17, aveVehicles);
        }

        [TestMethod]
        public void TimeOfDayCountTest()
        {
            // Arrange
            string data = @"Reference Number,Grid Ref: Easting,Grid Ref: Northing,Number of Vehicles,Expr1,Accident Date,Time (24hr),1st Road Class,Road Surface,Lighting Conditions,Weather Conditions,Casualty Class,Casualty Severity,Sex of Casualty,Age of Casualty,Type of Vehicle
2181280,418241,442351,2,Leeds 2016,08/01/2016,1905,A,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Serious,Male,38,Motorcycle over 500cc
2191037,424993,432898,2,Leeds 2016,09/01/2016,1615,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,50,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,26,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,22,Car
3C41220,432240,426274,2,Leeds 2016,04/12/2016,1610,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,57,Car
3C41498,436776,443749,9,Leeds 2016,04/12/2016,1925,A,Dry,Darkness: no street lighting,Fine without high winds,Vehicle or pillion passenger,Slight,Male,18,Car
";

            List<RoadTrafficIncident> roadTrafficIncidents = _rtcDataService.GetDataList(data);
            DateTime timeFrom = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 19, 0, 0);
            DateTime timeTo = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 20, 0, 0);

            // Act
            int count = _rtcDataService.TotalNumberOfIncidentsByTime(roadTrafficIncidents, timeFrom, timeTo);

            // Assert
            Assert.AreEqual(2, count);
        }

        [TestMethod]
        public void MonthlyTableTest()
        {
            // Arrange
            string data = @"Reference Number,Grid Ref: Easting,Grid Ref: Northing,Number of Vehicles,Expr1,Accident Date,Time (24hr),1st Road Class,Road Surface,Lighting Conditions,Weather Conditions,Casualty Class,Casualty Severity,Sex of Casualty,Age of Casualty,Type of Vehicle
2181280,418241,442351,2,Leeds 2016,08/01/2016,1905,A,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Serious,Male,38,Motorcycle over 500cc
2191037,424993,432898,2,Leeds 2016,09/01/2016,1615,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,50,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,26,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,22,Car
3111091,439313,432376,2,Leeds 2016,01/01/2016,0956,A,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,57,Pedal cycle
3111178,426994,439957,2,Leeds 2016,01/01/2016,1115,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,59,Pedal cycle
3111395,427813,431257,1,Leeds 2016,01/01/2016,1352,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Female,53,Car
3111981,431496,432727,2,Leeds 2016,01/01/2016,2015,Unclassified,Wet / Damp,Darkness: street lights present and lit,Raining without high winds,Vehicle or pillion passenger,Slight,Female,22,Car
3120560,431880,430498,2,Leeds 2016,02/01/2016,1110,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,20,Car
3120872,429425,433999,1,Leeds 2016,02/01/2016,1638,A(M),Wet / Damp,Darkness: street lights present and lit,Raining without high winds,Driver or rider,Slight,Male,22,Car
3120872,429425,433999,1,Leeds 2016,02/01/2016,1638,A(M),Wet / Damp,Darkness: street lights present and lit,Raining without high winds,Vehicle or pillion passenger,Slight,Female,26,Car
3210161,440272,449564,2,Leeds 2016,01/02/2016,0500,Unclassified,Wet / Damp,Darkness: street lights present and lit,Fine with high winds,Driver or rider,Slight,Male,34,Car
3210475,431026,433540,1,Leeds 2016,01/02/2016,1039,Unclassified,Wet / Damp,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,28,Car
3210607,435675,434795,3,Leeds 2016,01/02/2016,1205,Unclassified,Dry,Daylight: street lights present,Fine with high winds,Driver or rider,Slight,Female,52,Car
3210607,435675,434795,3,Leeds 2016,01/02/2016,1205,Unclassified,Dry,Daylight: street lights present,Fine with high winds,Driver or rider,Slight,Female,66,Car
3210942,431881,435453,1,Leeds 2016,01/02/2016,1530,Unclassified,Dry,Daylight: street lights present,Fine with high winds,Pedestrian,Slight,Female,85,Car
3210980,432858,435382,2,Leeds 2016,01/02/2016,1545,Unclassified,Dry,Daylight: street lights present,Unknown,Vehicle or pillion passenger,Slight,Male,6,Car
3210980,432858,435382,2,Leeds 2016,01/02/2016,1545,Unclassified,Dry,Daylight: street lights present,Unknown,Vehicle or pillion passenger,Slight,Female,9,Car
3210980,432858,435382,2,Leeds 2016,01/02/2016,1545,Unclassified,Dry,Daylight: street lights present,Unknown,Vehicle or pillion passenger,Slight,Female,10,Car
3211478,426743,427878,1,Leeds 2016,01/02/2016,1510,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Female,26,Goods vehicle 3.5 tonnes mgw and under
3220231,432173,425966,2,Leeds 2016,02/02/2016,0810,Motorway,Dry,Daylight: street lights present,Fine with high winds,Driver or rider,Slight,Male,31,Car
3220493,430785,424533,2,Leeds 2016,02/02/2016,1126,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,73,Car
3221429,427896,436200,2,Leeds 2016,02/02/2016,1800,A,Wet / Damp,Darkness: street lights present and lit,Unknown,Driver or rider,Slight,Male,41,Pedal cycle
3310258,443655,437652,1,Leeds 2016,01/03/2016,0855,A(M),Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,54,Goods vehicle 7.5 tonnes mgw and over
3310294,427620,433951,2,Leeds 2016,01/03/2016,0910,Unclassified,Dry,Daylight: street lights present,Raining without high winds,Driver or rider,Slight,Male,21,Pedal cycle
3310740,424049,435487,2,Leeds 2016,01/03/2016,1352,Unclassified,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,40,Car
3311182,430959,435871,2,Leeds 2016,01/03/2016,1755,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Male,46,Pedal cycle
3311442,430221,432990,1,Leeds 2016,01/03/2016,1951,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Pedestrian,Serious,Female,75,Taxi/Private hire car
3320182,430335,439815,1,Leeds 2016,02/03/2016,0730,Unclassified,Frost / Ice,Daylight: street lights present,Unknown,Driver or rider,Slight,Male,33,Motorcycle over 50cc and up to 125cc
3320201,426441,428146,3,Leeds 2016,02/03/2016,0737,Unclassified,Dry,Daylight: street lights present,Unknown,Driver or rider,Slight,Male,27,Goods vehicle 3.5 tonnes mgw and under
3320255,431556,435177,1,Leeds 2016,02/03/2016,0853,A,Snow,Daylight: street lights present,Snowing without high winds,Pedestrian,Serious,Female,25,Car
3320317,441601,448977,3,Leeds 2016,02/03/2016,0932,Unclassified,Snow,Daylight: street lights present,Unknown,Driver or rider,Slight,Male,39,Car
3320317,441601,448977,3,Leeds 2016,02/03/2016,0932,Unclassified,Snow,Daylight: street lights present,Unknown,Driver or rider,Slight,Female,38,Car
3320317,441601,448977,3,Leeds 2016,02/03/2016,0932,Unclassified,Snow,Daylight: street lights present,Unknown,Driver or rider,Slight,Female,79,Car
3320331,431201,440854,1,Leeds 2016,02/03/2016,0935,A,Snow,Daylight: street lights present,Snowing without high winds,Driver or rider,Slight,Male,19,Motorcycle over 50cc and up to 125cc
3320404,429963,432509,2,Leeds 2016,02/03/2016,0930,Unclassified,Dry,Daylight: street lights present,Unknown,Vehicle or pillion passenger,Slight,Female,45,Bus or coach (17 or more passenger seats)
3410726,432779,429909,2,Leeds 2016,01/04/2016,1330,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,32,Motorcycle over 50cc and up to 125cc
3411318,431229,445744,1,Leeds 2016,01/04/2016,1852,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,31,Car
3420318,429898,435437,1,Leeds 2016,02/04/2016,0630,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Female,30,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,59,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,28,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,46,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,60,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,24,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,27,Car
3420607,431966,425519,2,Leeds 2016,02/04/2016,1210,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,3,Car
3421179,427062,431803,2,Leeds 2016,02/04/2016,1810,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,34,Motorcycle over 500cc
3421556,430164,432839,2,Leeds 2016,02/04/2016,1420,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,23,Car
3421556,430164,432839,2,Leeds 2016,02/04/2016,1420,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,18,Car
3421556,430164,432839,2,Leeds 2016,02/04/2016,1420,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,45,Car
3531853,430606,434564,2,Leeds 2016,03/05/2016,2320,A,Wet / Damp,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,24,Car
3540209,435565,425884,3,Leeds 2016,04/05/2016,0738,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,22,Car
3540268,428067,426542,2,Leeds 2016,04/05/2016,0835,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,32,Car
3540271,435021,436216,2,Leeds 2016,04/05/2016,0842,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,14,Pedal cycle
3541105,428424,428709,3,Leeds 2016,04/05/2016,1638,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,37,Motorcycle over 500cc
3541510,436808,436502,1,Leeds 2016,04/05/2016,1810,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,6,Car
3550500,427325,431493,3,Leeds 2016,05/05/2016,1120,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,32,Car
3550500,427325,431493,3,Leeds 2016,05/05/2016,1120,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,53,Goods vehicle 3.5 tonnes mgw and under
3550500,427325,431493,3,Leeds 2016,05/05/2016,1120,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,29,Car
3551192,426727,431732,2,Leeds 2016,05/05/2016,1700,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,22,Car
3551673,430789,431378,1,Leeds 2016,05/05/2016,2201,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Serious,Male,24,Motorcycle over 50cc and up to 125cc
3560493,439389,432656,3,Leeds 2016,06/05/2016,1036,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,45,Goods vehicle 3.5 tonnes mgw and under
3560493,439389,432656,3,Leeds 2016,06/05/2016,1036,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,41,Car
3560710,436162,435075,1,Leeds 2016,06/05/2016,1240,A,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,70,Goods vehicle 3.5 tonnes mgw and under
3561186,425066,434279,2,Leeds 2016,06/05/2016,1630,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,21,M/cycle 50cc and under
3611239,443266,444199,2,Leeds 2016,01/06/2016,1822,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,38,Pedal cycle
3620591,431402,435029,2,Leeds 2016,02/06/2016,1214,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Female,53,Pedal cycle
3621398,418962,441738,2,Leeds 2016,02/06/2016,1730,B,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,21,Pedal cycle
3621562,426330,435490,2,Leeds 2016,02/06/2016,2030,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,56,Pedal cycle
3621592,425281,432980,2,Leeds 2016,02/06/2016,2045,B,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,49,Car
3621792,430529,433266,1,Leeds 2016,02/06/2016,2130,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Female,32,Car
3631313,431470,435116,1,Leeds 2016,03/06/2016,1847,A,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,75,Car
3631326,430072,433369,1,Leeds 2016,03/06/2016,1220,Unclassified,Dry,Daylight: street lights present,Unknown,Vehicle or pillion passenger,Slight,Male,4,Bus or coach (17 or more passenger seats)
3631374,429386,435421,2,Leeds 2016,03/06/2016,1930,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,21,Motorcycle over 50cc and up to 125cc
3631506,428311,435077,2,Leeds 2016,03/06/2016,2040,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,24,Pedal cycle
3631784,430062,433712,2,Leeds 2016,03/06/2016,0520,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Female,21,Pedal cycle
3640633,428381,434053,2,Leeds 2016,02/06/2016,1816,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,27,Car
3640633,428381,434053,2,Leeds 2016,02/06/2016,1816,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,5,Car
3640635,429412,433945,2,Leeds 2016,04/06/2016,1142,A(M),Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,32,Car
3640741,427793,434427,2,Leeds 2016,04/06/2016,1245,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,29,Car
3640741,427793,434427,2,Leeds 2016,04/06/2016,1245,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,36,Car
3720563,432455,438756,1,Leeds 2016,02/07/2016,1057,Unclassified,Wet / Damp,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Female,73,Car
3720858,431340,435054,2,Leeds 2016,02/07/2016,1408,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,54,Car
3721063,432158,427337,2,Leeds 2016,02/07/2016,1601,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,51,Car
3721063,432158,427337,2,Leeds 2016,02/07/2016,1601,Motorway,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,62,Car
3721135,430577,425368,1,Leeds 2016,02/07/2016,1652,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,51,Taxi/Private hire car
3721156,425970,436323,1,Leeds 2016,02/07/2016,1652,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Serious,Male,65,Car
3721205,430780,433454,1,Leeds 2016,02/07/2016,1526,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,70,Bus or coach (17 or more passenger seats)
3721205,430780,433454,1,Leeds 2016,02/07/2016,1526,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,50,Bus or coach (17 or more passenger seats)
3721205,430780,433454,1,Leeds 2016,02/07/2016,1526,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,47,Bus or coach (17 or more passenger seats)
3721205,430780,433454,1,Leeds 2016,02/07/2016,1526,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,51,Bus or coach (17 or more passenger seats)
3730711,427891,436195,2,Leeds 2016,03/07/2016,1153,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,29,Pedal cycle
3730942,425708,435406,2,Leeds 2016,03/07/2016,1430,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,32,Motorcycle over 50cc and up to 125cc
3731246,435544,438371,2,Leeds 2016,03/07/2016,1712,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,64,Car
3731246,435544,438371,2,Leeds 2016,03/07/2016,1712,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,76,Car
3731308,421928,441435,2,Leeds 2016,03/07/2016,1740,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,45,Car
3731431,429980,430876,2,Leeds 2016,03/07/2016,1800,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,37,Mobility Scooter
3740214,429334,435000,2,Leeds 2016,04/07/2016,0605,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,28,Pedal cycle
3811059,427116,433512,1,Leeds 2016,01/08/2016,1550,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,62,Bus or coach (17 or more passenger seats)
3811315,431381,435355,2,Leeds 2016,01/08/2016,1800,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,31,Car
3811595,431908,435069,2,Leeds 2016,01/08/2016,2019,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,37,Car
3811595,431908,435069,2,Leeds 2016,01/08/2016,2019,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,25,Taxi/Private hire car
3820302,428302,434114,2,Leeds 2016,02/08/2016,0815,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,31,Pedal cycle
3821313,430667,434302,2,Leeds 2016,02/08/2016,1830,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,55,Pedal cycle
3830263,428872,432496,2,Leeds 2016,03/08/2016,0655,Unclassified,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,47,Pedal cycle
3830291,431692,441552,1,Leeds 2016,03/08/2016,0745,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,27,Car
3830335,435875,426021,2,Leeds 2016,03/08/2016,0845,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,54,Car
3830729,427485,434593,2,Leeds 2016,03/08/2016,1330,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,29,Pedal cycle
3831111,427957,433622,2,Leeds 2016,03/08/2016,1559,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,53,Taxi/Private hire car
3831228,420750,445646,1,Leeds 2016,03/08/2016,1600,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Male,36,Pedal cycle
3840846,433898,434034,2,Leeds 2016,04/08/2016,1410,B,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,44,M/cycle 50cc and under
3840919,426991,427914,2,Leeds 2016,04/08/2016,1215,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,38,Bus or coach (17 or more passenger seats)
3840919,426991,427914,2,Leeds 2016,04/08/2016,1215,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,37,Bus or coach (17 or more passenger seats)
3841523,434120,433913,2,Leeds 2016,04/08/2016,1957,B,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,44,Car
3841523,434120,433913,2,Leeds 2016,04/08/2016,1957,B,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,18,Car
3850395,430539,436997,2,Leeds 2016,05/08/2016,0920,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,30,Car
3921449,429479,431201,2,Leeds 2016,02/09/2016,1807,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,15,M/cycle 50cc and under
3930215,431514,438536,2,Leeds 2016,03/09/2016,0235,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,22,Car
3930839,422424,432775,3,Leeds 2016,03/09/2016,1305,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Driver or rider,Serious,Male,64,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Driver or rider,Slight,Male,53,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Female,38,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Female,12,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Driver or rider,Slight,Male,25,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Male,4,Car
3930957,431229,434786,2,Leeds 2016,03/09/2016,1425,Unclassified,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Male,41,Car
3931321,427519,435875,2,Leeds 2016,03/09/2016,1530,B,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,27,Car
3931892,428750,434077,2,Leeds 2016,03/09/2016,2350,Unclassified,Wet / Damp,Darkness: street lights present and lit,Fine without high winds,Vehicle or pillion passenger,Slight,Female,22,Taxi/Private hire car
3940394,428526,432685,2,Leeds 2016,04/09/2016,0800,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,34,Car
3940520,423345,444486,2,Leeds 2016,04/09/2016,1025,A,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,21,Car
3940520,423345,444486,2,Leeds 2016,04/09/2016,1025,A,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,66,Car
3940520,423345,444486,2,Leeds 2016,04/09/2016,1025,A,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Serious,Female,60,Car
3941118,437762,432564,2,Leeds 2016,04/09/2016,1630,Motorway,Wet / Damp,Daylight: street lights present,Raining without high winds,Driver or rider,Slight,Female,28,Car
3941118,437762,432564,2,Leeds 2016,04/09/2016,1630,Motorway,Wet / Damp,Daylight: street lights present,Raining without high winds,Driver or rider,Slight,Male,42,Car
3941118,437762,432564,2,Leeds 2016,04/09/2016,1630,Motorway,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Female,42,Car
3941118,437762,432564,2,Leeds 2016,04/09/2016,1630,Motorway,Wet / Damp,Daylight: street lights present,Raining without high winds,Vehicle or pillion passenger,Slight,Male,21,Car
3A31406,436137,427930,2,Leeds 2016,03/10/2016,0500,A,Dry,Darkness: street lighting unknown,Unknown,Driver or rider,Slight,Male,28,Car
3A31453,424506,434441,2,Leeds 2016,03/10/2016,1745,B,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,38,Pedal cycle
3A31485,427600,436795,2,Leeds 2016,03/10/2016,1911,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,36,Pedal cycle
3A40219,439316,432380,2,Leeds 2016,04/10/2016,0748,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,23,Car
3A40325,437575,433215,2,Leeds 2016,03/10/2016,1630,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,30,Car
3A40735,432794,434287,1,Leeds 2016,04/10/2016,1307,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,20,Motorcycle over 50cc and up to 125cc
3A41340,432221,433184,1,Leeds 2016,04/10/2016,1800,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,17,Motorcycle over 125cc and up to 500cc
3A50232,435674,434794,2,Leeds 2016,05/10/2016,0850,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,46,Car
3A50248,427963,433621,2,Leeds 2016,05/10/2016,0837,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,42,Pedal cycle
3A50290,436330,434209,2,Leeds 2016,05/10/2016,0900,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,21,Motorcycle over 50cc and up to 125cc
3B20858,424151,428163,2,Leeds 2016,02/11/2016,1418,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,22,Car
3B20858,424151,428163,2,Leeds 2016,02/11/2016,1418,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,26,Car
3B21094,431913,435719,2,Leeds 2016,02/11/2016,1600,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,38,Goods vehicle 3.5 tonnes mgw and under
3B21115,428718,426013,2,Leeds 2016,02/11/2016,1614,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,23,Car
3B21115,428718,426013,2,Leeds 2016,02/11/2016,1614,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,50,Car
3B21169,429030,431750,5,Leeds 2016,02/11/2016,1645,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,31,Car
3B21169,429030,431750,5,Leeds 2016,02/11/2016,1645,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Female,36,Car
3B21169,429030,431750,5,Leeds 2016,02/11/2016,1645,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,30,Car
3B21169,429030,431750,5,Leeds 2016,02/11/2016,1645,Motorway,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Serious,Male,31,Car
3B21169,429030,431750,5,Leeds 2016,02/11/2016,1645,Motorway,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Male,10,Car
3B21483,429788,430628,2,Leeds 2016,02/11/2016,1900,A,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Male,39,Pedal cycle
3C40865,432213,434656,2,Leeds 2016,04/12/2016,1335,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,47,Car
3C40865,432213,434656,2,Leeds 2016,04/12/2016,1335,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,39,Car
3C40941,431470,433501,1,Leeds 2016,04/12/2016,1422,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Pedestrian,Slight,Female,8,Car
3C41053,435737,436946,2,Leeds 2016,04/12/2016,1526,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,25,Car
3C41053,435737,436946,2,Leeds 2016,04/12/2016,1526,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,69,Car
3C41053,435737,436946,2,Leeds 2016,04/12/2016,1526,A,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,48,Car
3C41203,430759,439910,2,Leeds 2016,04/12/2016,1645,Unclassified,Wet / Damp,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,25,Car
3C41203,430759,439910,2,Leeds 2016,04/12/2016,1645,Unclassified,Wet / Damp,Darkness: street lights present and lit,Fine without high winds,Vehicle or pillion passenger,Slight,Male,25,Car
3C41203,430759,439910,2,Leeds 2016,04/12/2016,1645,Unclassified,Wet / Damp,Darkness: street lights present and lit,Fine without high winds,Vehicle or pillion passenger,Serious,Male,1,Car
3C41220,432240,426274,2,Leeds 2016,04/12/2016,1610,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,30,Car
3C41220,432240,426274,2,Leeds 2016,04/12/2016,1610,Motorway,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Female,57,Car
3C41498,436776,443749,1,Leeds 2016,04/12/2016,1925,A,Dry,Darkness: no street lighting,Fine without high winds,Vehicle or pillion passenger,Slight,Male,18,Car
";
            int[] monthlyIncidentCount = new int[12];
            List<RoadTrafficIncident> roadTrafficIncidents = _rtcDataService.GetDataList(data);
            
            int totalIncidents = _rtcDataService.TotalNumberOfIncidents(roadTrafficIncidents);
            
            for (int i=0; i<12; i++)
            {
                monthlyIncidentCount[i] = _rtcDataService.TotalNumberOfIncidentsByMonth(roadTrafficIncidents, i+1);
            }

            // Act
            List<MonthlyIncident> monthlyIncidents = new List<MonthlyIncident>();
            monthlyIncidents.Add(new MonthlyIncident { Month = "Month", Count = "Count", Percent = "Percent" });
            for (int i=0; i<12; i++)
            {
                monthlyIncidents.Add(new MonthlyIncident { Month = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(i+1), Count = monthlyIncidentCount[i].ToString(), Percent = ((monthlyIncidentCount[i] * 100.0) / totalIncidents).ToString() });
            }

            //Assert
            Assert.AreEqual(13, monthlyIncidents.Count);

        }

        [TestMethod]
        public void MinMaxAvgTableTest()
        {
            // Arrange
            string data = @"Reference Number,Grid Ref: Easting,Grid Ref: Northing,Number of Vehicles,Expr1,Accident Date,Time (24hr),1st Road Class,Road Surface,Lighting Conditions,Weather Conditions,Casualty Class,Casualty Severity,Sex of Casualty,Age of Casualty,Type of Vehicle
2181280,418241,442351,2,Leeds 2016,08/01/2016,1905,A,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Serious,Male,38,Motorcycle over 500cc
2191037,424993,432898,2,Leeds 2016,09/01/2016,1615,Unclassified,Dry,Darkness: street lights present and lit,Fine without high winds,Driver or rider,Slight,Female,50,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,26,Car
2CQ0870,431159,436397,2,Leeds 2016,15/01/2016,1645,Unclassified,Dry,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,22,Car
3111091,439313,432376,2,Leeds 2016,01/01/2016,0956,A,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Slight,Male,57,Pedal cycle
3111178,426994,439957,2,Leeds 2016,01/01/2016,1115,A,Dry,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Male,59,Pedal cycle
3111395,427813,431257,1,Leeds 2016,01/01/2016,1352,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Driver or rider,Serious,Female,53,Car
3111981,431496,432727,2,Leeds 2016,01/01/2016,2015,Unclassified,Wet / Damp,Darkness: street lights present and lit,Raining without high winds,Vehicle or pillion passenger,Slight,Female,22,Car
3120560,431880,430498,2,Leeds 2016,02/01/2016,1110,Motorway,Wet / Damp,Daylight: street lights present,Fine without high winds,Vehicle or pillion passenger,Slight,Female,20,Car
3120872,429425,433999,1,Leeds 2016,02/01/2016,1638,A(M),Wet / Damp,Darkness: street lights present and lit,Raining without high winds,Driver or rider,Slight,Male,22,Car
3C41498,436776,443749,1,Leeds 2016,04/12/2016,1925,A,Dry,Darkness: no street lighting,Fine without high winds,Vehicle or pillion passenger,Slight,Male,18,Car
";
            List<RoadTrafficIncident> roadTrafficIncidents = _rtcDataService.GetDataList(data);
            int minVehicles = _rtcDataService.MinimumVehicles(roadTrafficIncidents);
            int maxVehicles = _rtcDataService.MaximumVehicles(roadTrafficIncidents);
            double avgVehicles = _rtcDataService.AverageVehicles(roadTrafficIncidents);

            // Act
            List<IncidentStatistics> incidentStatistics = new List<IncidentStatistics>();
            incidentStatistics.Add(new IncidentStatistics { Metric = "Metric", Count = "Count" });
            incidentStatistics.Add(new IncidentStatistics { Metric = "Minimum", Count = minVehicles.ToString()});
            incidentStatistics.Add(new IncidentStatistics { Metric = "Maximum", Count = maxVehicles.ToString() });
            incidentStatistics.Add(new IncidentStatistics { Metric = "Average", Count = avgVehicles.ToString() });

            // Assert
            Assert.AreEqual(4, incidentStatistics.Count);
        }

        [TestMethod]
        public void PeakTableTest()
        {
            // Arrange
            _roadTrafficIncidents = _rtcDataService.GetDataList(_data);
            DateTime[] timeFrom = new DateTime[2];
            DateTime[] timeTo = new DateTime[2];

            timeFrom[0] = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 8, 0, 0); ;
            timeTo[0] = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 0, 0);
            timeFrom[1] = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 0, 0);
            timeTo[1] = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 18, 0, 0);

            // Act
            List<PeakTimeStatistics> peakTimeStatistics = _rtcViewDataService.GetPeaktimeStatisticsTable(_roadTrafficIncidents, timeFrom, timeTo);

            // Assert
            Assert.AreEqual(3, peakTimeStatistics.Count);
        }
    }
}
