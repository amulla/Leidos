﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoadTraffic.Domain
{
    public class MonthlyIncident
    {
        public string Month { get; set; }
        public string Count { get; set; }
        public string Percent { get; set; }
    }
}
