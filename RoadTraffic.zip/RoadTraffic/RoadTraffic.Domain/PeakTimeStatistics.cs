﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoadTraffic.Domain
{
    public class PeakTimeStatistics
    {
        public string Timeframe;
        public string Count;
        public string Percent;
    }
}
