﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoadTraffic.Domain
{
    public class RoadTrafficIncident
    {
        public string ReferenceNumber { get; set; }
        public string GridRefEasting { get; set; }
        public string GridRefNorthing { get; set; }
        public int NumberOfVehicles { get; set; }
        public string Expr1 { get; set; }
        public DateTime IncidentDate { get; set; }
        public DateTime IncidentTime { get; set; }
        public string FirstRoadClass { get; set; }
        public string RoadSurface { get; set; }
        public string LightingConditions { get; set; }
        public string WeatherConditions { get; set; }
        public string CasualtyClass { get; set; }
        public string CasualtySeverity { get; set; }
        public string SexOfCasualty { get; set; }
        public int AgeOfCasualty { get; set; }
        public string TypeOfVehicle { get; set; }
    }
}
