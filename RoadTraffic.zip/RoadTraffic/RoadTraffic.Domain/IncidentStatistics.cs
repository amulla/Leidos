﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoadTraffic.Domain
{
    public class IncidentStatistics
    {
        public string Metric;
        public string Count;
    }
}
