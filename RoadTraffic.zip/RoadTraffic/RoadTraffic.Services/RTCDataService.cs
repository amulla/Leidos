﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using RoadTraffic.Domain;

namespace RoadTraffic.Services
{
    public interface IRTCDataService
    {
        string GetData(string url);
        List<RoadTrafficIncident> GetDataList(string data);

        int TotalNumberOfIncidents(List<RoadTrafficIncident> roadTrafficIncidentList);
        int TotalNumberOfIncidentsByMonth(List<RoadTrafficIncident> roadTrafficIncidentList, int targetMonth);
        int MinimumVehicles(List<RoadTrafficIncident> roadTrafficIncidentList);
        int MaximumVehicles(List<RoadTrafficIncident> roadTrafficIncidentList);
        double AverageVehicles(List<RoadTrafficIncident> roadTrafficIncidentList);
        int TotalNumberOfIncidentsByTime(List<RoadTrafficIncident> roadTrafficIncidentList, DateTime fromTime, DateTime toTime);

    }
    public class RTCDataService : IRTCDataService
    {
        public string GetData(string url)
        {
            string data = string.Empty;

            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
                HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
                StreamReader sr = new StreamReader(resp.GetResponseStream());

                data = sr.ReadToEnd();
                sr.Close();
            }
            catch
            {
            }

            return data;
        }

        public List<RoadTrafficIncident> GetDataList(string data)
        {
            List<RoadTrafficIncident> roadTrafficIncidentList = new List<RoadTrafficIncident>();

            try
            {
                var lines = data.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries).Skip(1);

                foreach (var item in lines)
                {
                    var values = item.Split(',');
                    var rti = new RoadTrafficIncident
                    {
                        ReferenceNumber = values[0],
                        GridRefEasting = values[1],
                        GridRefNorthing = values[2],
                        NumberOfVehicles = Int32.Parse(values[3]),
                        Expr1 = values[4],
                        IncidentDate = DateTime.Parse(values[5]),
                        IncidentTime = DateTime.ParseExact(values[6], "HHmm", null),
                        FirstRoadClass = values[7],
                        RoadSurface = values[8],
                        LightingConditions = values[9],
                        WeatherConditions = values[10],
                        CasualtyClass = values[11],
                        CasualtySeverity = values[12],
                        SexOfCasualty = values[13],
                        AgeOfCasualty = Int32.Parse(values[14]),
                        TypeOfVehicle = values[15]
                    };

                    roadTrafficIncidentList.Add(rti);
                }
            }
            catch
            {
            }

            return roadTrafficIncidentList;
        }

        public int TotalNumberOfIncidents(List<RoadTrafficIncident> roadTrafficIncidentList)
        {
            return roadTrafficIncidentList.Count;
        }

        public int TotalNumberOfIncidentsByMonth(List<RoadTrafficIncident> roadTrafficIncidentList, int targetMonth)
        {
            return roadTrafficIncidentList.Where(i => i.IncidentDate.Month == targetMonth).Count();
        }

        public int MinimumVehicles(List<RoadTrafficIncident> roadTrafficIncidentList)
        {
            return roadTrafficIncidentList.Min(i => i.NumberOfVehicles);
        }

        public int MaximumVehicles(List<RoadTrafficIncident> roadTrafficIncidentList)
        {
            return roadTrafficIncidentList.Max(i => i.NumberOfVehicles);
        }

        public double AverageVehicles(List<RoadTrafficIncident> roadTrafficIncidentList)
        {
            return Math.Round(roadTrafficIncidentList.Average(i => i.NumberOfVehicles), 2);
        }

        public int TotalNumberOfIncidentsByTime(List<RoadTrafficIncident> roadTrafficIncidentList, DateTime fromTime, DateTime toTime)
        {
            return roadTrafficIncidentList.Where(i => i.IncidentTime >= fromTime && i.IncidentTime <= toTime).Count();
        }

    }
}
