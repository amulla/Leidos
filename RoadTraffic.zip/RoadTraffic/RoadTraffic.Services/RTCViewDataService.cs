﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RoadTraffic.Domain;
using System.Globalization;

namespace RoadTraffic.Services
{
    public interface IRTCViewDataService
    {
        List<MonthlyIncident> GetMonthlyIncidentTable(List<RoadTrafficIncident> roadTrafficIncidents);
        List<IncidentStatistics> GetIncidentStatisticsTable(List<RoadTrafficIncident> roadTrafficIncidents);
        List<PeakTimeStatistics> GetPeaktimeStatisticsTable(List<RoadTrafficIncident> roadTrafficIncidents, DateTime[] timeFrom, DateTime[] timeTo);
    }
    public class RTCViewDataService : IRTCViewDataService
    {
        private IRTCDataService _rtcDataService;

        public RTCViewDataService(IRTCDataService rtcDataService)
        {
            _rtcDataService = rtcDataService;
        }

        public List<MonthlyIncident> GetMonthlyIncidentTable(List<RoadTrafficIncident> roadTrafficIncidents)
        {
            List<MonthlyIncident> monthlyIncidents = new List<MonthlyIncident>();
            int[] monthlyIncidentCount = new int[12];
            int totalIncidents = _rtcDataService.TotalNumberOfIncidents(roadTrafficIncidents);

            for (int i = 0; i < 12; i++)
            {
                monthlyIncidentCount[i] = _rtcDataService.TotalNumberOfIncidentsByMonth(roadTrafficIncidents, i + 1);
            }

            // Act
            monthlyIncidents.Add(new MonthlyIncident { Month = "Month", Count = "Count", Percent = "Percent" });
            for (int i = 0; i < 12; i++)
            {
                monthlyIncidents.Add(new MonthlyIncident { Month = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(i + 1), Count = monthlyIncidentCount[i].ToString(), Percent = ((monthlyIncidentCount[i] * 100.0) / totalIncidents).ToString("0.##") });
            }

            return monthlyIncidents;
        }

        public List<IncidentStatistics> GetIncidentStatisticsTable(List<RoadTrafficIncident> roadTrafficIncidents)
        {
            List<IncidentStatistics> incidentStatistics = new List<IncidentStatistics>();

            int minVehicles = _rtcDataService.MinimumVehicles(roadTrafficIncidents);
            int maxVehicles = _rtcDataService.MaximumVehicles(roadTrafficIncidents);
            double avgVehicles = _rtcDataService.AverageVehicles(roadTrafficIncidents);

            // Act
            incidentStatistics.Add(new IncidentStatistics { Metric = "Metric", Count = "Count" });
            incidentStatistics.Add(new IncidentStatistics { Metric = "Minimum", Count = minVehicles.ToString() });
            incidentStatistics.Add(new IncidentStatistics { Metric = "Maximum", Count = maxVehicles.ToString() });
            incidentStatistics.Add(new IncidentStatistics { Metric = "Average", Count = avgVehicles.ToString() });


            return incidentStatistics;
        }

        public List<PeakTimeStatistics> GetPeaktimeStatisticsTable(List<RoadTrafficIncident> roadTrafficIncidents, DateTime[] timeFrom, DateTime[] timeTo)
        {
            List<PeakTimeStatistics> peaktimeStatistics = new List<PeakTimeStatistics>();

            int totalIncidents = _rtcDataService.TotalNumberOfIncidents(roadTrafficIncidents);
            peaktimeStatistics.Add(new PeakTimeStatistics { Timeframe = "Timeframe", Count = "Count", Percent = "Percent" });

            for (int i = 0; i < timeFrom.Count(); i++)
            {
                int total = _rtcDataService.TotalNumberOfIncidentsByTime(roadTrafficIncidents, timeFrom[i], timeTo[i]);
                string timeframe = String.Format("{0} - {1}", timeFrom[i].ToString("HH:mm"), timeTo[i].ToString("HH:mm"));
                peaktimeStatistics.Add(new PeakTimeStatistics { Timeframe = timeframe, Count = total.ToString(), Percent = ((total * 100.0 / totalIncidents).ToString("0.##")) });
            }

            return peaktimeStatistics;
        }
    }
}
